/* FreeNetHub-API - simple, deploy-ready server.js */
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { join } = require('path');
const fs = require('fs');
const fetch = require('node-fetch');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { Low, JSONFile } = require('lowdb');
const shortid = require('shortid');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

const dbFile = join(__dirname, 'db.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);

async function initDB(){
  await db.read();
  db.data = db.data || { users: [], marketplace: [], tasks: [], transactions: [], leaderboard: [], analytics: {}, sims: [], wifi_sources: [], subscriptions: [] };
  if(!db.data.subscriptions || db.data.subscriptions.length===0){
    db.data.subscriptions = [{id:'basic',name:'Basic',price:0},{id:'pro',name:'Pro',price:299},{id:'premium',name:'Premium',price:499}];
  }
  await db.write();
}
initDB();

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
function createToken(u){ return jwt.sign({ id: u.id, email: u.email, name: u.name, is_admin: u.is_admin||false }, JWT_SECRET, { expiresIn: '30d' }); }
async function auth(req,res,next){
  try{
    const h = req.headers.authorization;
    if(!h) return res.status(401).json({ error:'no_auth' });
    const token = h.split(' ')[1];
    const d = jwt.verify(token, JWT_SECRET);
    await db.read();
    const user = db.data.users.find(x=>x.id===d.id);
    if(!user) return res.status(401).json({ error:'unknown_user' });
    req.user = user;
    next();
  }catch(e){
    return res.status(401).json({ error:'invalid_token' });
  }
}

app.get('/api/status', async (req,res)=>{ await db.read(); db.data.analytics.visits = (db.data.analytics.visits||0) + 1; await db.write(); res.json({ ok:true, time: Date.now() }); });

app.post('/api/register', async (req,res)=>{
  const { name, email, password } = req.body;
  if(!email || !password) return res.status(400).json({ error:'missing' });
  await db.read();
  if(db.data.users.find(u=>u.email===email)) return res.status(400).json({ error:'exists' });
  const hashed = await bcrypt.hash(password, 8);
  const user = { id: shortid.generate(), name: name||'User', email, password: hashed, credits:0, is_admin:false, referralCode:('REF'+Math.random().toString(36).slice(2,8).toUpperCase()), data_balance_mb:0 };
  db.data.users.push(user);
  await db.write();
  res.json({ user: { id:user.id, name:user.name, email:user.email, credits:user.credits, referralCode:user.referralCode, data_balance_mb:user.data_balance_mb }, token: createToken(user) });
});

app.post('/api/login', async (req,res)=>{
  const { email, password } = req.body;
  await db.read();
  const user = db.data.users.find(u=>u.email===email);
  if(!user) return res.status(400).json({ error:'invalid' });
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(400).json({ error:'invalid' });
  res.json({ user: { id:user.id, name:user.name, email:user.email, credits:user.credits, referralCode:user.referralCode, data_balance_mb:user.data_balance_mb }, token: createToken(user) });
});

app.get('/auth/google-info', (req,res)=>{ res.json({ message: 'Enable Google OAuth in environment variables. See README.' }); });

app.get('/api/create-admin', async (req,res)=>{ const email = req.query.email; if(!email) return res.status(400).json({ error:'missing_email' }); await db.read(); const user = db.data.users.find(u=>u.email===email); if(!user) return res.status(404).json({ error:'user_not_found' }); user.is_admin = true; await db.write(); return res.json({ ok:true, message: `User ${email} promoted to admin.` }); });

app.get('/api/marketplace', async (req,res)=>{ await db.read(); res.json({ items: db.data.marketplace || [] }); });
app.post('/api/admin/marketplace', auth, async (req,res)=>{ if(!req.user.is_admin) return res.status(403).json({ error:'forbidden' }); const { title, description, price, qty } = req.body; await db.read(); const it = { id: shortid.generate(), title, description, price: price||0, qty: qty||1 }; db.data.marketplace.push(it); await db.write(); res.json(it); });

app.get('/api/tasks', async (req,res)=>{ await db.read(); res.json({ tasks: db.data.tasks || [] }); });
app.post('/api/admin/tasks', auth, async (req,res)=>{ if(!req.user.is_admin) return res.status(403).json({ error:'forbidden' }); const { title, description, reward } = req.body; await db.read(); const t = { id: shortid.generate(), title, description, reward: reward||1, completed_by: [] }; db.data.tasks.push(t); await db.write(); res.json(t); });
app.post('/api/tasks/complete', auth, async (req,res)=>{ const { taskId } = req.body; await db.read(); const task = db.data.tasks.find(t=>t.id===taskId); if(!task) return res.status(404).json({ error:'no' }); if(task.completed_by.includes(req.user.id)) return res.status(400).json({ error:'done' }); task.completed_by.push(req.user.id); const u = db.data.users.find(x=>x.id===req.user.id); u.credits = (u.credits||0) + (task.reward||1); await db.write(); res.json({ success:true, reward: task.reward }); });

app.get('/api/leaderboard', async (req,res)=>{ await db.read(); res.json({ leaderboard: db.data.leaderboard || [] }); });
app.post('/api/referral/redeem', auth, async (req,res)=>{ const { code } = req.body; await db.read(); let item = db.data.leaderboard.find(l=>l.code===code); if(!item){ item = { id: shortid.generate(), name: code, code, referrals: 0 }; db.data.leaderboard.push(item); } item.referrals = (item.referrals||0) + 1; await db.write(); res.json({ success:true, item }); });

app.get('/api/subscriptions', async (req,res)=>{ await db.read(); res.json({ subscriptions: db.data.subscriptions || [] }); });

app.post('/api/telco/register-sim', auth, async (req,res)=>{ const { msisdn, operator } = req.body; if(!msisdn) return res.status(400).json({ error:'missing' }); await db.read(); let s = db.data.sims.find(x=>x.msisdn===msisdn); if(!s){ s = { id: shortid.generate(), msisdn, operator: operator||'unknown', owner: req.user.id, bundles: [] }; db.data.sims.push(s); await db.write(); } res.json({ sim: s }); });

app.post('/api/admin/wifi-source', auth, async (req,res)=>{ if(!req.user.is_admin) return res.status(403).json({ error:'forbidden' }); const { name, ssid, bundles } = req.body; await db.read(); const w = { id: shortid.generate(), name, ssid, bundles: bundles || [] }; db.data.wifi_sources.push(w); await db.write(); res.json(w); });

app.get('/api/telco/bundles', auth, async (req,res)=>{ await db.read(); const built = [{ code:'SIM-100MB', label:'100MB', mb:100 }, { code:'SIM-1GB', label:'1GB', mb:1024 }, { code:'SIM-5GB', label:'5GB', mb:5120 }]; const wifiBundles = (db.data.wifi_sources||[]).flatMap(w=>w.bundles||[]); res.json({ source:'local', bundles: built.concat(wifiBundles) }); });

app.post('/api/telco/provision', auth, async (req,res)=>{ const { msisdn, bundle_code, wifi_id } = req.body; if(!msisdn && !wifi_id) return res.status(400).json({ error:'missing' }); await db.read(); const ref = 'prov_'+Date.now(); db.data.transactions.push({ id: shortid.generate(), provider:'telco', type:'provision', user_id: req.user.id, external_order_id: ref, msisdn, wifi_id, bundle_code, credited:0, raw_payload:{requested:true} }); const bundles = [{ code:'SIM-100MB', mb:100 }, { code:'SIM-1GB', mb:1024 }, { code:'SIM-5GB', mb:5120 }]; const b = bundles.find(x=>x.code===bundle_code) || { code:bundle_code, mb:100 }; const user = db.data.users.find(u=>u.id===req.user.id); user.data_balance_mb = (user.data_balance_mb||0) + b.mb; db.data.transactions[db.data.transactions.length-1].credited = 1; await db.write(); res.json({ success:true, simulated:true, added_mb: b.mb, new_balance: user.data_balance_mb }); });

const MPESA_CONSUMER_KEY = process.env.MPESA_CONSUMER_KEY || '';
const MPESA_CONSUMER_SECRET = process.env.MPESA_CONSUMER_SECRET || '';
const MPESA_SHORTCODE = process.env.MPESA_SHORTCODE || '';
const MPESA_PASSKEY = process.env.MPESA_PASSKEY || '';
const MPESA_CALLBACK_URL = process.env.MPESA_CALLBACK_URL || '';

async function getMpesaToken(){
  try{
    if(!MPESA_CONSUMER_KEY || !MPESA_CONSUMER_SECRET) return null;
    const basic = Buffer.from(MPESA_CONSUMER_KEY + ':' + MPESA_CONSUMER_SECRET).toString('base64');
    const r = await fetch('https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials', { headers:{ Authorization: 'Basic ' + basic }});
    if(!r.ok) return null;
    const j = await r.json(); return j.access_token;
  }catch(e){ console.error('mpesa token err', e); return null; }
}

app.post('/api/payments/mpesa/stkpush', auth, async (req,res)=>{ const { phone, amount } = req.body; if(!phone || !amount) return res.status(400).json({ error:'missing' }); await db.read(); const token = await getMpesaToken(); const checkout = 'CHK_'+Date.now(); const tx = { id: shortid.generate(), provider:'mpesa', type:'stkpush', user_id: req.user.id, checkout_request_id: checkout, amount, phone, credited:0, raw_payload:{started:true} }; db.data.transactions.push(tx); await db.write(); if(!token) return res.json({ success:true, provider:'mpesa', message:'token_unavailable_simulated', checkout }); res.json({ success:true, provider:'mpesa', checkout }); });

app.post('/api/payments/mpesa/callback', async (req,res)=>{ await db.read(); db.data.transactions.push({ id: shortid.generate(), provider:'mpesa', type:'callback', raw_payload: req.body }); await db.write(); res.json({ received:true }); });

const PAYPAL_CLIENT = process.env.PAYPAL_CLIENT || '';
const PAYPAL_SECRET = process.env.PAYPAL_SECRET || '';

async function getPaypalToken(){ try{ if(!PAYPAL_CLIENT || !PAYPAL_SECRET) return null; const b = Buffer.from(PAYPAL_CLIENT + ':' + PAYPAL_SECRET).toString('base64'); const r = await fetch('https://api-m.sandbox.paypal.com/v1/oauth2/token', { method:'POST', headers:{ Authorization:'Basic '+b, 'Content-Type':'application/x-www-form-urlencoded' }, body: 'grant_type=client_credentials' }); if(!r.ok) return null; const j = await r.json(); return j.access_token; }catch(e){ return null; } }

app.post('/api/payments/paypal/create-order', auth, async (req,res)=>{ const { amount } = req.body; await db.read(); const token = await getPaypalToken(); const order = { id: 'ORDER_'+Date.now(), links: [{ rel:'approve', href:'https://www.sandbox.paypal.com/checkoutnow?token=SIMULATED' }] }; db.data.transactions.push({ id: shortid.generate(), provider:'paypal', type:'order', external_order_id: order.id, amount, credited:0, raw_payload:order, user_id: req.user.id }); await db.write(); res.json({ success:true, order, approve_url: order.links[0].href }); });

app.post('/api/payments/paypal/webhook', async (req,res)=>{ await db.read(); db.data.transactions.push({ id: shortid.generate(), provider:'paypal', type:'webhook', raw:req.body }); await db.write(); res.json({ received:true }); });

const publicDir = join(__dirname, 'public');
if(!fs.existsSync(publicDir)) fs.mkdirSync(publicDir);
if(!fs.existsSync(join(publicDir,'index.html'))) fs.writeFileSync(join(publicDir,'index.html'), '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FreeNetHub</title></head><body><h1>FreeNetHub API</h1><p>Use /api/status to test.</p></body></html>');

const PORT = process.env.PORT || 3000;
app.use('/', express.static(publicDir));
app.listen(PORT, ()=> console.log('FreeNetHub-API listening on', PORT));
